# ==================================================
# ZPID-V0.1 - Zenith Processor Identification
# ==================================================

Clear-Host

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "         ZPID-V0.1 - CPU Identification           " -ForegroundColor Yellow
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host ""

try {
    $cpu = Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop

    Write-Host "  [+] Processor Name:  " -NoNewline -ForegroundColor Green
    Write-Host $cpu.Name

    Write-Host "  [+] Manufacturer:    " -NoNewline -ForegroundColor Green
    Write-Host $cpu.Manufacturer

    Write-Host "  [+] Cores:           " -NoNewline -ForegroundColor Green
    Write-Host $cpu.NumberOfCores

    Write-Host "  [+] Threads:         " -NoNewline -ForegroundColor Green
    Write-Host $cpu.NumberOfLogicalProcessors

    Write-Host "  [+] Max Speed:       " -NoNewline -ForegroundColor Green
    Write-Host "$($cpu.MaxClockSpeed) MHz"

    Write-Host "  [+] Socket Type:     " -NoNewline -ForegroundColor Green
    Write-Host $cpu.SocketDesignation
}
catch {
    Write-Host "  [!] Error reading CPU data: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "Press ENTER to exit ZPID-V0.1..." -ForegroundColor Gray
Read-Host
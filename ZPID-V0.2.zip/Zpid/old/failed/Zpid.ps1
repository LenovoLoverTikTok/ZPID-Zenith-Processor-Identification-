Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase -ErrorAction SilentlyContinue

# Hardware gegevens ophalen via WMI
$cpu = Get-CimInstance Win32_Processor
$baseClockGHz = [math]::Round($cpu.CurrentClockSpeed / 1000, 2)
$cpuName = $cpu.Name.Trim()
$cpuUpper = $cpuName.ToUpper()

# Cache geheugen ophalen
try {
    $caches = Get-CimInstance Win32_CacheMemory -ErrorAction SilentlyContinue
    $l1Cache = ($caches | Where-Object { $_.Level -eq 3 } | Measure-Object -Property InstalledSize -Sum).Sum
    $l2Cache = ($caches | Where-Object { $_.Level -eq 4 } | Measure-Object -Property InstalledSize -Sum).Sum
    $l3Cache = ($caches | Where-Object { $_.Level -eq 5 } | Measure-Object -Property InstalledSize -Sum).Sum

    $l1Text = if ($l1Cache) { "$l1Cache KB" } else { "N/B" }
    $l2Text = if ($l2Cache) { "$([math]::Round($l2Cache / 1024, 1)) MB" } else { "N/B" }
    $l3Text = if ($l3Cache) { "$([math]::Round($l3Cache / 1024, 1)) MB" } else { "N/B" }
} catch {
    $l1Text = "N/B"; $l2Text = "N/B"; $l3Text = "N/B"
}

# Fabrikant bepalen
$manufacturerText = $cpu.Manufacturer
if ($manufacturerText -match "AuthenticAMD") {
    $manufacturerText = "AMD"
} elseif ($manufacturerText -match "GenuineIntel") {
    $manufacturerText = "Intel"
}

# --- PROCESSOR FAMILY DETECTIE ---
$familyText = "Onbekend"
if ($cpuUpper -match "RYZEN 9") { $familyText = "AMD Ryzen 9" }
elseif ($cpuUpper -match "RYZEN 7") { $familyText = "AMD Ryzen 7" }
elseif ($cpuUpper -match "RYZEN 5") { $familyText = "AMD Ryzen 5" }
elseif ($cpuUpper -match "RYZEN 3") { $familyText = "AMD Ryzen 3" }
elseif ($cpuUpper -match "RYZEN") { $familyText = "AMD Ryzen" }
elseif ($cpuUpper -match "ATHLON GOLD") { $familyText = "AMD Athlon Gold" }
elseif ($cpuUpper -match "ATHLON SILVER") { $familyText = "AMD Athlon Silver" }
elseif ($cpuUpper -match "ATHLON") { $familyText = "AMD Athlon" }
elseif ($cpuUpper -match "FX") { $familyText = "AMD FX" }
elseif ($cpuUpper -match "I9" -or $cpuUpper -match "CORE 9" -or $cpuUpper -match "CORE(TM) I9") { $familyText = "Intel Core i9" }
elseif ($cpuUpper -match "I7" -or $cpuUpper -match "CORE 7" -or $cpuUpper -match "CORE(TM) I7") { $familyText = "Intel Core i7" }
elseif ($cpuUpper -match "I5" -or $cpuUpper -match "CORE 5" -or $cpuUpper -match "CORE(TM) I5") { $familyText = "Intel Core i5" }
elseif ($cpuUpper -match "I3" -or $cpuUpper -match "CORE 3" -or $cpuUpper -match "CORE(TM) I3") { $familyText = "Intel Core i3" }
elseif ($cpuUpper -match "CELERON") { $familyText = "Intel Celeron" }
elseif ($cpuUpper -match "PENTIUM") { $familyText = "Intel Pentium" }
elseif ($cpuUpper -match "XEON") { $familyText = "Intel Xeon" }
elseif ($cpuUpper -match "INTEL") { $familyText = "Intel Processor" }

# --- LITHOGRAFIE (NM) DETECTIE ---
$nmText = "Onbekend"

# AMD NM
if ($manufacturerText -eq "AMD") {
    if ($cpuUpper -match "9\d{3}") { $nmText = "4 nm" }
    elseif ($cpuUpper -match "8\d{3}" -or $cpuUpper -match "7\d{3}") { $nmText = "5 nm / 4 nm" }
    elseif ($cpuUpper -match "6\d{3}") { $nmText = "6 nm" }
    elseif ($cpuUpper -match "5\d{3}") { $nmText = "7 nm" }
    elseif ($cpuUpper -match "4\d{3}" -or $cpuUpper -match "3\d{3}") { $nmText = "7 nm / 12 nm" }
    elseif ($cpuUpper -match "3000G" -or $cpuUpper -match "300U" -or $cpuUpper -match "3150" -or $cpuUpper -match "3050" -or $cpuUpper -match "200GE") { $nmText = "14 nm / 12 nm" }
    elseif ($cpuUpper -match "ATHLON") { $nmText = "14 nm / 28 nm" }
    else { $nmText = "14 nm" }
}
# INTEL NM
else {
    if ($cpuUpper -match "-12" -or $cpuUpper -match "-13" -or $cpuUpper -match "-14" -or $cpuUpper -match "12\d{3}" -or $cpuUpper -match "13\d{3}" -or $cpuUpper -match "14\d{3}") { $nmText = "10 nm (Intel 7)" }
    elseif ($cpuUpper -match "-10" -or $cpuUpper -match "-11" -or $cpuUpper -match "10\d{3}" -or $cpuUpper -match "11\d{3}") { $nmText = "10 nm" }
    elseif ($cpuUpper -match "-6" -or $cpuUpper -match "-7" -or $cpuUpper -match "-8" -or $cpuUpper -match "-9" -or $cpuUpper -match "6\d{3}" -or $cpuUpper -match "7\d{3}" -or $cpuUpper -match "8\d{3}" -or $cpuUpper -match "9\d{3}") { $nmText = "14 nm" }
    elseif ($cpuUpper -match "-3" -or $cpuUpper -match "-4" -or $cpuUpper -match "3\d{3}" -or $cpuUpper -match "4\d{3}") { $nmText = "22 nm" }
    elseif ($cpuUpper -match "-2" -or $cpuUpper -match "2\d{3}") { $nmText = "32 nm" }
    else { $nmText = "14 nm" }
}

# --- TDP DETECTIE ---
$tdpText = "65 W"

# Laptops / Ultra low power
if ($cpuUpper -match "U" -or $cpuUpper -match "Y" -or $cpuUpper -match "MOBILE" -or $cpuUpper -match "G1" -or $cpuUpper -match "G4" -or $cpuUpper -match "G7" -or $cpuUpper -match "3020E") { 
    $tdpText = "15 W" 
}
# High Performance Laptops
elseif ($cpuUpper -match "H" -or $cpuUpper -match "HS" -or $cpuUpper -match "HX" -or $cpuUpper -match "HQ" -or $cpuUpper -match "HK") { 
    $tdpText = "45 W" 
}
# Low Power Desktops
elseif ($cpuUpper -match "3000G" -or $cpuUpper -match "200GE" -or $cpuUpper -match "300GE" -or $cpuUpper -match "GE" -or $cpuUpper -match " T ") { 
    $tdpText = "35 W" 
}
# High End Desktops
elseif ($cpuUpper -match "K" -or $cpuUpper -match "X3D" -or $cpuUpper -match "X" -or $cpuUpper -match "KF" -or $cpuUpper -match "KS") { 
    $tdpText = "105 W - 125 W" 
}
# Standaard Athlon Desktops
elseif ($cpuUpper -match "ATHLON") { 
    $tdpText = "35 W / 65 W" 
}

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Zenith Processor Identification v2.5" Height="620" Width="540"
        MinHeight="520" MinWidth="480"
        WindowStartupLocation="CenterScreen" ResizeMode="CanResize"
        Background="#1E1E1E" Foreground="#FFFFFF" FontFamily="Segoe UI Variable, Segoe UI">
    
    <Grid Margin="20">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- Header -->
        <Border Grid.Row="0" Background="#2D2D2D" CornerRadius="8" Padding="15" Margin="0,0,0,15">
            <StackPanel Orientation="Horizontal">
                <Border Width="40" Height="40" Background="#0078D4" CornerRadius="6" Margin="0,0,15,0">
                    <TextBlock Text="Z" Foreground="White" FontSize="22" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center"/>
                </Border>
                <StackPanel VerticalAlignment="Center">
                    <TextBlock Text="ZPID Processor Information" FontSize="16" FontWeight="SemiBold" Foreground="#FFFFFF"/>
                    <TextBlock Text="Zenith Hardware Utility v2.5" FontSize="11" Foreground="#A0A0A0"/>
                </StackPanel>
            </StackPanel>
        </Border>

        <!-- Main Card met Processor Specificaties -->
        <Border Grid.Row="1" Background="#2D2D2D" CornerRadius="8" Padding="15">
            <ScrollViewer VerticalScrollBarVisibility="Auto">
                <StackPanel Name="SpecList">
                    
                    <!-- Processor Model & Manufacturer -->
                    <Grid Margin="0,0,0,10">
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="10"/>
                            <ColumnDefinition Width="*"/>
                        </Grid.ColumnDefinitions>

                        <Border Grid.Column="0" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="PROCESSOR MODEL" FontSize="10" FontWeight="Bold" Foreground="#60CDFF" Margin="0,0,0,4"/>
                                <TextBlock Text="$cpuName" FontSize="13" FontWeight="SemiBold" TextWrapping="Wrap"/>
                            </StackPanel>
                        </Border>

                        <Border Grid.Column="2" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="MANUFACTURER" FontSize="10" FontWeight="Bold" Foreground="#60CDFF" Margin="0,0,0,4"/>
                                <TextBlock Text="$manufacturerText" FontSize="13" FontWeight="Bold" Foreground="#60CDFF" TextWrapping="Wrap"/>
                            </StackPanel>
                        </Border>
                    </Grid>

                    <!-- Family & Lithography -->
                    <Grid Margin="0,0,0,10">
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="10"/>
                            <ColumnDefinition Width="*"/>
                        </Grid.ColumnDefinitions>

                        <Border Grid.Column="0" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="PROCESSOR FAMILY" FontSize="10" FontWeight="Bold" Foreground="#A0A0A0" Margin="0,0,0,2"/>
                                <TextBlock Text="$familyText" FontSize="14" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>

                        <Border Grid.Column="2" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="LITHOGRAPHY" FontSize="10" FontWeight="Bold" Foreground="#A0A0A0" Margin="0,0,0,2"/>
                                <TextBlock Text="$nmText" FontSize="14" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>
                    </Grid>

                    <!-- Cores & Threads -->
                    <Grid Margin="0,0,0,10">
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="10"/>
                            <ColumnDefinition Width="*"/>
                        </Grid.ColumnDefinitions>
                        
                        <Border Grid.Column="0" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="PHYSICAL CORES" FontSize="10" FontWeight="Bold" Foreground="#A0A0A0" Margin="0,0,0,2"/>
                                <TextBlock Text="$($cpu.NumberOfCores)" FontSize="18" FontWeight="Bold" Foreground="#FFFFFF"/>
                            </StackPanel>
                        </Border>

                        <Border Grid.Column="2" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="LOGICAL THREADS" FontSize="10" FontWeight="Bold" Foreground="#A0A0A0" Margin="0,0,0,2"/>
                                <TextBlock Text="$($cpu.NumberOfLogicalProcessors)" FontSize="18" FontWeight="Bold" Foreground="#FFFFFF"/>
                            </StackPanel>
                        </Border>
                    </Grid>

                    <!-- Base Clock & TDP -->
                    <Grid Margin="0,0,0,10">
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="10"/>
                            <ColumnDefinition Width="*"/>
                        </Grid.ColumnDefinitions>

                        <Border Grid.Column="0" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="BASE CLOCK SPEED" FontSize="10" FontWeight="Bold" Foreground="#A0A0A0" Margin="0,0,0,2"/>
                                <TextBlock Text="$baseClockGHz GHz" FontSize="15" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>

                        <Border Grid.Column="2" Background="#252525" CornerRadius="6" Padding="12">
                            <StackPanel>
                                <TextBlock Text="TDP POWER" FontSize="10" FontWeight="Bold" Foreground="#A0A0A0" Margin="0,0,0,2"/>
                                <TextBlock Text="$tdpText" FontSize="15" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>
                    </Grid>

                    <!-- Caches (L1, L2, L3) -->
                    <Grid Margin="0,0,0,10">
                        <Grid.ColumnDefinitions>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="8"/>
                            <ColumnDefinition Width="*"/>
                            <ColumnDefinition Width="8"/>
                            <ColumnDefinition Width="*"/>
                        </Grid.ColumnDefinitions>

                        <Border Grid.Column="0" Background="#252525" CornerRadius="6" Padding="10">
                            <StackPanel>
                                <TextBlock Text="L1 CACHE" FontSize="10" FontWeight="Bold" Foreground="#60CDFF"/>
                                <TextBlock Text="$l1Text" FontSize="13" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>

                        <Border Grid.Column="2" Background="#252525" CornerRadius="6" Padding="10">
                            <StackPanel>
                                <TextBlock Text="L2 CACHE" FontSize="10" FontWeight="Bold" Foreground="#60CDFF"/>
                                <TextBlock Text="$l2Text" FontSize="13" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>

                        <Border Grid.Column="4" Background="#252525" CornerRadius="6" Padding="10">
                            <StackPanel>
                                <TextBlock Text="L3 CACHE" FontSize="10" FontWeight="Bold" Foreground="#60CDFF"/>
                                <TextBlock Text="$l3Text" FontSize="13" FontWeight="SemiBold"/>
                            </StackPanel>
                        </Border>
                    </Grid>

                </StackPanel>
            </ScrollViewer>
        </Border>

        <!-- Bottom Bar met 'Close' Knop -->
        <Grid Grid.Row="2" Margin="0,15,0,0">
            <TextBlock Text="ZenithOS Compatible Engine" VerticalAlignment="Center" Foreground="#707070" FontSize="11"/>
            <Button Name="CloseBtn" Content="Close" HorizontalAlignment="Right" Width="90" Height="30" 
                    Background="#0078D4" Foreground="White" BorderThickness="0" FontWeight="SemiBold">
                <Button.Resources>
                    <Style TargetType="Border">
                        <Setter Property="CornerRadius" Value="4"/>
                    </Style>
                </Button.Resources>
            </Button>
        </Grid>
    </Grid>
</Window>
"@

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

$closeButton = $window.FindName("CloseBtn")
$closeButton.Add_Click({ $window.Close() })

$window.ShowDialog() | Out-Null
# ==================================================
# ZPID-V0.2 - Zenith Processor Identification
# ==================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Fetch CPU Information via WMI
$cpu = Get-CimInstance -ClassName Win32_Processor

# Create Main Window
$form = New-Object System.Windows.Forms.Form
$form.Text = "ZPID-V0.2 - CPU Identification"
$form.Size = New-Object System.Drawing.Size(420,320)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $False
$form.BackColor = [System.Drawing.Color]::FromArgb(240, 240, 240)

# Title Label
$title = New-Object System.Windows.Forms.Label
$title.Text = "ZPID - Zenith Processor Identification (v0.2)"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::DarkBlue
$title.Size = New-Object System.Drawing.Size(380, 30)
$title.Location = New-Object System.Drawing.Point(20, 15)
$form.Controls.Add($title)

# Information Text Panel
$label = New-Object System.Windows.Forms.Label
$label.Size = New-Object System.Drawing.Size(360, 180)
$label.Location = New-Object System.Drawing.Point(20, 50)
$label.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
$label.Text = "Processor Name:`t" + $cpu.Name + "`n`n" +
              "Manufacturer:`t" + $cpu.Manufacturer + "`n" +
              "Cores:`t`t" + $cpu.NumberOfCores + "`n" +
              "Threads:`t`t" + $cpu.NumberOfLogicalProcessors + "`n" +
              "Max Clock Speed:`t" + $cpu.MaxClockSpeed + " MHz`n" +
              "Socket Type:`t`t" + $cpu.SocketDesignation

$form.Controls.Add($label)

# Close Button
$button = New-Object System.Windows.Forms.Button
$button.Text = "Close"
$button.Location = New-Object System.Drawing.Point(280, 235)
$button.Size = New-Object System.Drawing.Size(90, 30)
$button.Add_Click({ $form.Close() })
$form.Controls.Add($button)

# Display Window
[void]$form.ShowDialog()
@echo off
powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0ZPID-V0.2.ps1"
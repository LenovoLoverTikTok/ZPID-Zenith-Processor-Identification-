@echo off
powershell.exe -ExecutionPolicy Bypass -NoExit -File "%~dp0ZPID.ps1"
pause